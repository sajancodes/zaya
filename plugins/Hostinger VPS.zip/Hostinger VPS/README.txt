- reminder.py--> actions/reminder.py(Put it under the actions folder)

- cloud_agent.py--> plugins/cloud_agent.py(put it under the plugins folder)

- cloud.py--> core/cloud.py(put it under the core folder)

After getting VPS, Follow this steps to use it:

1) Go to folder path(like: cd C:\User\Mark-LVIII)(Find your program's path by clicking right--> properties. Or you can just drag the program folder to CMD directly)

2) Paste this--> python -m core.cloud deploy root@123.45.67.89 (Change the root section with your own VPS's ID)

3) After that, enter your root password, it'll ask 2 times for the password and password will not be seen when you typing due to security of CMD (you can change your root password from the 'Hostinger VPS overview')

4)It will give something like that:

  Pairing code — paste it into JARVIS on your computer:
  jarvis-cloud://123.45.67.89:7443/Xk9pL2...#a3f1c8...
  
   copy this jarvis cloud token

5) Open our assistant program then follow: "UI-->Settings-->Plugin settings-->VPS" Then, just paste your token that you copied and make other settings according to your needs(Turn the buttons on/off, i's up to your choice)

6) Press test/sync and then save it.

7) You need to get telegram remote control to use it from phone as well. 

That's it.